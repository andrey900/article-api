<?php

return [

    'distinct' => [
        'must_be_selected' => 'Vähintään yksi :attribute kenttä tulee olla valittuna.',
        'only_one_must_be_selected' => 'Vain yksi :attribute kenttä tulee olla valittuna.',
    ],

];
