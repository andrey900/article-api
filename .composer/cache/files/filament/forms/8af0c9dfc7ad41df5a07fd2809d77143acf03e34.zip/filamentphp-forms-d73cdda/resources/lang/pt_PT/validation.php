<?php

return [

    'distinct' => [
        'must_be_selected' => 'Deve ser seleccionado, no mínimo, um campo :attribute.',
        'only_one_must_be_selected' => 'Apenas um campo :attribute deve ser seleccionado.',
    ],

];
