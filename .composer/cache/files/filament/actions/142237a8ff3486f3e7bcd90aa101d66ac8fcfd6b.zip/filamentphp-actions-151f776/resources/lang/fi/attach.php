<?php

return [

    'single' => [

        'label' => 'Liitä',

        'modal' => [

            'heading' => 'Liitä :label',

            'fields' => [

                'record_id' => [
                    'label' => 'Tietue',
                ],

            ],

            'actions' => [

                'attach' => [
                    'label' => 'Liitä',
                ],

                'attach_another' => [
                    'label' => 'Liitä & liitä toinen',
                ],

            ],

        ],

        'notifications' => [

            'attached' => [
                'title' => 'Liitetty',
            ],

        ],

    ],

];
