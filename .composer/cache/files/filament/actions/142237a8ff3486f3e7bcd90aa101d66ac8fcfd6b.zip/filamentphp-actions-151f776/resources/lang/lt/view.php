<?php

return [

    'single' => [

        'label' => 'Peržiūrėti',

        'modal' => [

            'heading' => 'Peržiūrėti :label',

            'actions' => [

                'close' => [
                    'label' => 'Uždaryti',
                ],

            ],

        ],

    ],

];
