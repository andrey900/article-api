<?php

return [

    'trigger' => [
        'label' => 'Actions',
    ],

];
