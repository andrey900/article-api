<?php

return [

    'single' => [

        'label' => 'ایجاد :label',

        'modal' => [

            'heading' => 'ایجاد :label',

            'actions' => [

                'create' => [
                    'label' => 'ایجاد',
                ],

                'create_another' => [
                    'label' => 'ایجاد و ایجاد یکی دیگر',
                ],

            ],

        ],

        'notifications' => [

            'created' => [
                'title' => 'ایجاد شد',
            ],

        ],

    ],

];
