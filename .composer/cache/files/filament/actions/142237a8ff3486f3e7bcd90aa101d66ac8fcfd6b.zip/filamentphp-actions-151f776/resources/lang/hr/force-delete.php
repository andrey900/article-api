<?php

return [

    'single' => [

        'label' => 'Prisilno obriši',

        'modal' => [

            'heading' => 'Prisilno obriši :label',

            'actions' => [

                'delete' => [
                    'label' => 'Obriši',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Obrisano',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Prisilno obriši odabrano',

        'modal' => [

            'heading' => 'Prisilno obriši odabrano',

            'actions' => [

                'delete' => [
                    'label' => 'Obriši',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Obrisano',
            ],

        ],

    ],

];
