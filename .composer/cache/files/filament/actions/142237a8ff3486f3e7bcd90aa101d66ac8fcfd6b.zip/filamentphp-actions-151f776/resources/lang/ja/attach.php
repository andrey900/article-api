<?php

return [

    'single' => [

        'label' => '紐付ける',

        'modal' => [

            'heading' => ':labelを紐付ける',

            'fields' => [

                'record_id' => [
                    'label' => 'レコード',
                ],

            ],

            'actions' => [

                'attach' => [
                    'label' => '紐付ける',
                ],

                'attach_another' => [
                    'label' => '紐付けして、続けて紐付ける',
                ],

            ],

        ],

        'notifications' => [

            'attached' => [
                'title' => '紐付けしました',
            ],

        ],

    ],

];
