<?php

return [

    'single' => [

        'label' => 'ပုံတူကူးရန်',

        'modal' => [

            'heading' => ':label ပုံတူကူးရန်',

            'actions' => [

                'replicate' => [
                    'label' => 'ပုံတူကူးရန်',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => 'ကူးယူပြီးပါပြီ',
            ],

        ],

    ],

];
