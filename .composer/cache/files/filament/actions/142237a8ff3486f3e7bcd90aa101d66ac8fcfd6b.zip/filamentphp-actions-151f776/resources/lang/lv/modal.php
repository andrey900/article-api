<?php

return [

    'confirmation' => 'Vai tiešām vēlaties to darīt?',

    'actions' => [

        'cancel' => [
            'label' => 'Atcelt',
        ],

        'confirm' => [
            'label' => 'Apstiprināt',
        ],

        'submit' => [
            'label' => 'Iesniegt',
        ],

    ],

];
