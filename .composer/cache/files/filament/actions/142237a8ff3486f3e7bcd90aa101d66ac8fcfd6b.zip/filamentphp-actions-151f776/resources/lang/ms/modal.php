<?php

return [

    'confirmation' => 'Adakah anda pasti mahu melakukan ini?',

    'actions' => [

        'cancel' => [
            'label' => 'Batal',
        ],

        'confirm' => [
            'label' => 'Sahkan',
        ],

        'submit' => [
            'label' => 'Hantar',
        ],

    ],

];
