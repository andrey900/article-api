<?php

namespace Filament\Support\Enums;

enum FontFamily
{
    case Sans;

    case Serif;

    case Mono;
}
