<?php

return [

    'messages' => [
        'uploading_file' => 'Đang tải tệp lên...',
    ],

];
