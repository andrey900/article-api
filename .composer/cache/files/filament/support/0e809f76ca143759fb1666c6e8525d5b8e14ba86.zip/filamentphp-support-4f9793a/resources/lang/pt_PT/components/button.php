<?php

return [

    'messages' => [
        'uploading_file' => 'A carregar ficheiro...',
    ],

];
