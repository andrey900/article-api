<?php

return [

    'messages' => [
        'copied' => 'لەبەرگیرا',
    ],

];
