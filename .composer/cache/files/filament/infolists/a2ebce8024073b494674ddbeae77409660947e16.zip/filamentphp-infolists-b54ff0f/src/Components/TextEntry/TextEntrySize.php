<?php

namespace Filament\Infolists\Components\TextEntry;

enum TextEntrySize
{
    case ExtraSmall;

    case Small;

    case Medium;

    case Large;
}
