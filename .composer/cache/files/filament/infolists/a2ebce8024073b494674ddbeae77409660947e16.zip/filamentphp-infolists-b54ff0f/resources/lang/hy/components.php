<?php

return [

    'entries' => [

        'text' => [

            'actions' => [
                'collapse_list' => 'Ցույց տալ :count-ից ավելի քիչ',
                'expand_list' => 'Ցույց տալ :count-ից ավելին',
            ],

            'more_list_items' => 'և :count-ից ավելին',

        ],

        'key_value' => [

            'columns' => [

                'key' => [
                    'label' => 'Բանալի',
                ],

                'value' => [
                    'label' => 'Արժեք',
                ],

            ],

            'placeholder' => 'Գրառումներ չկան',

        ],

    ],

];
