<?php

return [

    'entries' => [

        'text' => [

            'actions' => [
                'collapse_list' => ':count 개 더 접기',
                'expand_list' => ':count 개 더 펼치기',
            ],

            'more_list_items' => '그리고 :count 개 더',

        ],

        'key_value' => [

            'columns' => [

                'key' => [
                    'label' => '키',
                ],

                'value' => [
                    'label' => '값',
                ],

            ],

            'placeholder' => '항목 없음',

        ],

    ],

];
