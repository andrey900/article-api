<?php

return [

    'entries' => [

        'text' => [

            'actions' => [
                'collapse_list' => 'Покажи :count по-малко',
                'expand_list' => 'Покажи още :count',
            ],

            'more_list_items' => 'и още :count',

        ],

        'key_value' => [

            'columns' => [

                'key' => [
                    'label' => 'Ключ',
                ],

                'value' => [
                    'label' => 'Стойност',
                ],

            ],

            'placeholder' => 'Няма записи',

        ],

    ],

];
