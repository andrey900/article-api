<?php

return [

    'actions' => [

        'logout' => [
            'label' => 'Изход',
        ],

    ],

    'welcome' => 'Добре дошли',

];
