<?php

return [

    'field' => [
        'label' => 'Globalna pretraga',
        'placeholder' => 'Tražite',
    ],

    'no_results_message' => 'Nisu pronađeni rezultati pretrage.',

];
