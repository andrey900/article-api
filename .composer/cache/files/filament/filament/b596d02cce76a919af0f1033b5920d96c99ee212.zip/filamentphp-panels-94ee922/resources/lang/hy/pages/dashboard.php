<?php

return [

    'title' => 'Վահանակ',

    'actions' => [

        'filter' => [

            'label' => 'Ֆիլտր',

            'modal' => [

                'heading' => 'Ֆիլտր',

                'actions' => [

                    'apply' => [

                        'label' => 'Հաստատել',

                    ],

                ],

            ],

        ],

    ],

];
