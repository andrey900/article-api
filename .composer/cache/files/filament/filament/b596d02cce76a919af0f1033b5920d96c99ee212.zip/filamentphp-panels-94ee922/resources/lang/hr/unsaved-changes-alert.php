<?php

return [

    'body' => 'Tvoje izmjene nisu spremljene. Želiš li zaista napustiti ovu stranicu?',

];
