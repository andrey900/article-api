<?php

return [

    'title' => 'Afficher :label',

    'breadcrumb' => 'Afficher',

    'content' => [

        'tab' => [
            'label' => 'Afficher',
        ],

    ],

];
