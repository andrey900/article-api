<?php

return [

    'field' => [
        'label' => 'Vyhledávání',
        'placeholder' => 'Hledat',
    ],

    'no_results_message' => 'Nenalezeny žádné výsledky.',

];
