<?php

return [

    'modal' => [

        'heading' => '通知',

        'actions' => [

            'clear' => [
                'label' => '清除',
            ],

            'mark_all_as_read' => [
                'label' => '标记为已读',
            ],

        ],

        'empty' => [
            'heading' => '没有通知',
            'description' => '请稍后再查看。',
        ],

    ],

];
